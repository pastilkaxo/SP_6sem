#pragma once

#include <windows.h>
#include <ole2.h>
#include <olectl.h>
#include <specstrings.h>
#include <intsafe.h>
#include <strsafe.h>
#include <shlwapi.h>